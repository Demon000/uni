syms u
n = 3
[nodes, coefs, pin] = gauss_quad_sym(n, u)
